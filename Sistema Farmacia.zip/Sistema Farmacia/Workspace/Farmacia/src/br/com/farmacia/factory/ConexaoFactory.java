package br.com.farmacia.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoFactory {
    private static String url = "jdbc:postgresql://localhost:5432/teste";
    private static String user = "postgres";
    private static String password = "1234";
    
    
    public static Connection conectar() throws SQLException{
    	Connection conexao = DriverManager.getConnection(url, user, password);
    	return conexao;
    	
    }
    	
    public static void main(String[] args){
      	try {
    	    Connection conexao = ConexaoFactory.conectar();
    	    System.out.println("Conex�o bem-sucedida com o banco de dados PostgreSQL!");
    	   } catch (SQLException e) {
    	    System.out.println("Falha ao conectar ao banco de dados PostgreSQL!");
    	    e.printStackTrace();
    	}
   }
    
    
}




